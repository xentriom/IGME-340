package com.example.lab00

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
